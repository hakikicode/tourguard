<div class="copyrights">
	 <p>© 2020 TourGuard. All Rights Reserved |  <a href="#">TourGuard</a> </p>
</div>	
